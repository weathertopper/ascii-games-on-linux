Angband 4.1.3
=============

Angband is a graphical dungeon adventure game that uses textual characters
to represent the walls and floors of a dungeon and the inhabitants therein, 
in the vein of games like NetHack and Rogue.  If you need help in-game,
press '?'.

For more information, somewhere to upload your characters and screenshots,
and discuss the game, try http://angband.oook.cz/.

If you're compiling the game yourself, read http://trac.rephial.org/wiki/Compiling.

Enjoy!

-- The Angband Dev Team
